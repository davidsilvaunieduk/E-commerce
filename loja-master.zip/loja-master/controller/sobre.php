<?php

$smarty = new Template();
$smarty->assign('SOBRE', 'Página Sobre');
$smarty->display('sobre.tpl')

?>