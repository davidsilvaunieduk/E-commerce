<?php
/* Smarty version 3.1.36, created on 2020-06-30 13:14:08
  from 'C:\xampp\htdocs\loja\view\sobre.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5efb64d00d3f45_33328254',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '99ff2c84ab17630912e11016ff9e1d7b38d2df44' => 
    array (
      0 => 'C:\\xampp\\htdocs\\loja\\view\\sobre.tpl',
      1 => 1580769840,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5efb64d00d3f45_33328254 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="container my-5">
    <div class="row no-gutters text-center">
        <div class="col">
            <h4>Loja Carvalho</h4>
            <hr>
            <p>Loja E-commerce desenvolvido com auxílio de curso online.</p>
            <p><b>Linguagens utilizadas</b></p>
            <hr>
            <p><b>HTML 5</b> - Framework <b>BootStrap 4</b></p>
            <p>CSS 3 </p>
            <p><b>PHP 7 </b> Orientado a Objetos</p>
            <p>JavaScript</p>
            <h5>Banco de Dados</h5>
            <p>MySQL</p>
        </div>
    </div>
</div><?php }
}
