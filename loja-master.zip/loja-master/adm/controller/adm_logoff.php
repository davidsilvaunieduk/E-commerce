<?php

Login::LogoffADM();