<div class="container-fluid">
    <div class="row no-gutters">
        <div class="col-12">
        <h2 class="alert alert-danger text-center"><i class="fas fa-exclamation-triangle mr-2"></i>Página não encontrada!!!!</h2>
        </div>
    </div>
</div>